```python
# ATTENTION: Please do not alter any of the provided code in the exercise. Only add your own code where indicated
# ATTENTION: Please do not add or remove any cells in the exercise. The grader will check specific cells based on the cell position.
# ATTENTION: Please use the provided epoch values when training.

import csv
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from os import getcwd
```


```python
def get_data(filename):
  # You will need to write code that will read the file passed
  # into this function. The first line contains the column headers
  # so you should ignore it
  # Each successive line contians 785 comma separated values between 0 and 255
  # The first value is the label
  # The rest are the pixel values for that picture
  # The function will return 2 np.array types. One with all the labels
  # One with all the images
  #
  # Tips: 
  # If you read a full line (as 'row') then row[0] has the label
  # and row[1:785] has the 784 pixel values
  # Take a look at np.array_split to turn the 784 pixels into 28x28
  # You are reading in strings, but need the values to be floats
  # Check out np.array().astype for a conversion

    with open(filename) as training_file:
        csv_reader = csv.reader(training_file, delimiter=',')
        first_line = True
        temp_images = []
        temp_labels = []
        for row in csv_reader:
            if first_line:
                # print("Ignoring first line")
                first_line = False
            else:
                temp_labels.append(row[0])
                image_data = row[1:785]
                image_data_as_array = np.array_split(image_data, 28)
                temp_images.append(image_data_as_array)
        images = np.array(temp_images).astype('float')
        labels = np.array(temp_labels).astype('float')
    return images, labels

path_sign_mnist_train = f"{getcwd()}/../tmp2/sign_mnist_train.csv"
path_sign_mnist_test = f"{getcwd()}/../tmp2/sign_mnist_test.csv"
training_images, training_labels = get_data(path_sign_mnist_train)
testing_images, testing_labels = get_data(path_sign_mnist_test)

# Keep these
print(training_images.shape)
print(training_labels.shape)
print(testing_images.shape)
print(testing_labels.shape)

# Their output should be:
# (27455, 28, 28)
# (27455,)
# (7172, 28, 28)
# (7172,)
```

    (27455, 28, 28)
    (27455,)
    (7172, 28, 28)
    (7172,)



```python
# In this section you will have to add another dimension to the data
# So, for example, if your array is (10000, 28, 28)
# You will need to make it (10000, 28, 28, 1)
# Hint: np.expand_dims

training_images = np.expand_dims(training_images, axis=3)
testing_images = np.expand_dims(testing_images, axis=3)

train_datagen = ImageDataGenerator(
    rescale=1. / 255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest')

validation_datagen = ImageDataGenerator(
    rescale=1. / 255)

print(training_images.shape)
print(testing_images.shape)
    
# Their output should be:
# (27455, 28, 28, 1)
# (7172, 28, 28, 1)
```

    (27455, 28, 28, 1)
    (7172, 28, 28, 1)



```python
# Define the model
# Use no more than 2 Conv2D and 2 MaxPooling2D
model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
    tf.keras.layers.MaxPooling2D(2, 2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(512, activation='relu'),
    tf.keras.layers.Dense(26, activation='softmax')])

# Compile Model. 
model.compile(optimizer='rmsprop',
    loss='sparse_categorical_crossentropy',
    metrics=['acc'])

# Train the Model
history = model.fit_generator(train_datagen.flow(training_images,
                                                 training_labels,
                                                 batch_size=20),
                              epochs=15,
                              validation_data = validation_datagen.flow(testing_images,
                                                                 testing_labels,
                                                                 batch_size=20)
                             )

model.evaluate(testing_images, testing_labels, verbose=0)
```

    Epoch 1/15
    1373/1373 [==============================] - 79s 57ms/step - loss: 2.5051 - acc: 0.2341 - val_loss: 1.3529 - val_acc: 0.5577
    Epoch 2/15
    1373/1373 [==============================] - 76s 55ms/step - loss: 1.6183 - acc: 0.4799 - val_loss: 0.8672 - val_acc: 0.7164
    Epoch 3/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 1.1651 - acc: 0.6181 - val_loss: 0.5025 - val_acc: 0.8151
    Epoch 4/15
    1373/1373 [==============================] - 78s 57ms/step - loss: 0.9171 - acc: 0.6958 - val_loss: 0.4008 - val_acc: 0.8560
    Epoch 5/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 0.7612 - acc: 0.7504 - val_loss: 0.5264 - val_acc: 0.8129
    Epoch 6/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 0.6741 - acc: 0.7796 - val_loss: 0.2913 - val_acc: 0.8788
    Epoch 7/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 0.5964 - acc: 0.8045 - val_loss: 0.2693 - val_acc: 0.8908
    Epoch 8/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 0.5415 - acc: 0.8199 - val_loss: 0.1835 - val_acc: 0.9388
    Epoch 9/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 0.5053 - acc: 0.8361 - val_loss: 0.1909 - val_acc: 0.9375
    Epoch 10/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 0.4638 - acc: 0.8472 - val_loss: 0.1731 - val_acc: 0.9281
    Epoch 11/15
    1373/1373 [==============================] - 77s 56ms/step - loss: 0.4628 - acc: 0.8539 - val_loss: 0.1985 - val_acc: 0.9370
    Epoch 12/15
    1373/1373 [==============================] - 80s 59ms/step - loss: 0.4403 - acc: 0.8624 - val_loss: 0.2035 - val_acc: 0.9313
    Epoch 13/15
    1373/1373 [==============================] - 78s 57ms/step - loss: 0.4396 - acc: 0.8586 - val_loss: 0.1294 - val_acc: 0.9516
    Epoch 14/15
    1373/1373 [==============================] - 78s 56ms/step - loss: 0.4245 - acc: 0.8683 - val_loss: 0.1488 - val_acc: 0.9544
    Epoch 15/15
    1373/1373 [==============================] - 78s 57ms/step - loss: 0.4169 - acc: 0.8715 - val_loss: 0.2563 - val_acc: 0.9102





    [206.95368808591027, 0.68363076]




```python
# Plot the chart for accuracy and loss on both training and validation
%matplotlib inline
import matplotlib.pyplot as plt
acc = history.history['acc']
val_acc = history.history['val_acc']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs = range(len(acc))

plt.plot(epochs, acc, 'r', label='Training accuracy')
plt.plot(epochs, val_acc, 'b', label='Validation accuracy')
plt.title('Training and validation accuracy')
plt.legend()
plt.figure()

plt.plot(epochs, loss, 'r', label='Training Loss')
plt.plot(epochs, val_loss, 'b', label='Validation Loss')
plt.title('Training and validation loss')
plt.legend()

plt.show()
```


![png](output_4_0.png)



![png](output_4_1.png)


# Submission Instructions


```python
# Now click the 'Submit Assignment' button above.
```

# When you're done or would like to take a break, please run the two cells below to save your work and close the Notebook. This will free up resources for your fellow learners. 


```javascript
%%javascript
<!-- Save the notebook -->
IPython.notebook.save_checkpoint();
```


```javascript
%%javascript
IPython.notebook.session.delete();
window.onbeforeunload = null
setTimeout(function() { window.close(); }, 1000);
```
